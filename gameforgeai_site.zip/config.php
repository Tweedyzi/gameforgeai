
<?php
// Clé API OpenAI sécurisée
define('OPENAI_API_KEY', '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');
?>
